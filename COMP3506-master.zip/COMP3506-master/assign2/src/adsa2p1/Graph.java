package adsa2p1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;


public class Graph {

	// KEYS:one vertex on the edge VALUES:other vertices on the edge
	LinkedHashMap<String, Vertex> vertex;

	// Collection<Vertex> values = vertex.values();

	/**
	 * @param HashMap
	 *            of vertices from the input file
	 * @return
	 **/
	public Graph(LinkedHashMap<String, Vertex> myvertex) {
		this.vertex = myvertex;
	}
	

	/**
	 * Task2 
	 * @return the first step
	 **/
	public int getSize() {
		
		return vertex.size();
	}
	
	/**
	 * Task2 
	 * @return A keySet
	 **/
	public LinkedHashMap<Integer,String> TransKey() {
		LinkedHashMap<Integer,String> courseKey = new LinkedHashMap<Integer,String>();
		Set<String> iKeyset = vertex.keySet();//Keys
		int ct=0;
		for(String s : iKeyset){
			ct++;
			courseKey.put(ct, s);
		}
		return courseKey;
	}

	/**
	 * Task1
	 *
	 * @param (v1:start v2:end) || (v2:start v1:end)
	 * @return If the edge is available
	 **/

	public LinkedHashMap<String, Integer> getNonEdge() {
		int roomNum = 0;
		String v1 = null;
		ArrayList<String> checker = new ArrayList<String>();// Store read value
		ArrayList<String> list = new ArrayList<String>();// Adjacent list
		ArrayList<String> sameroom = new ArrayList<String>();
		LinkedHashMap<String, Integer> solution = new LinkedHashMap<String, Integer>();
		solution.put("room", 0);
		for (Entry<String, Vertex> entry : vertex.entrySet()) {
			v1 = entry.getKey();
			solution.put(v1, null);
			//System.out.println("Key: " + v1);
			sameroom.clear();
			if (checker.size() < 1) {
				checker.add(v1);
				roomNum = 1;
				solution.put(v1, roomNum);
			} else {
				for (int i = 0; i < checker.size(); i++) {

					String x = checker.get(i);
					//list = vertex.get(x).AdjacentList;
					//System.out.println("x: " + x);
					// Crash Time
					if (list.contains(v1) && solution.get(v1) == null
							&& x != v1) {
						//System.out.println(x + " Crash " + v1);
						checker.add(v1);
						roomNum++;
						solution.put(v1, roomNum);
						//System.out.println("Course:" + v1 + " Room:" + roomNum);
					} else if (!list.contains(v1)
							&& x != v1) {// Not Crash Time
					//	System.out.println(x + " Not Crash " + v1);
						int copyNum = solution.get(x);
					//	System.out.println("Copy Room:" + copyNum);
						// Checking the course code in checker has been a same
						// room
						for (Entry<String, Integer> entry1 : solution
								.entrySet()) {
							//System.out.println("entry: " + entry1.getValue()
								//	+ "--->" + entry1.getKey());
							if (entry1.getValue() != null) {
								if (entry1.getValue() == copyNum) {
									sameroom.add(entry1.getKey());
									//System.out.println(" SameRoom list add: "
										//	+ entry1.getKey() + "room"
											//+ copyNum);
								}
							}

						}
						//System.out.println(" SameRoom list size ="
							//+ sameroom.size());

						for (String course : sameroom) {
							//System.out.println("sameCourse=="+course);
							list = vertex.get(course).AdjacentList;
							if (list.contains(v1)) {
								//System.out.println(course + " Crash " + v1);
								roomNum++;
								solution.put(v1, roomNum);
								//System.out.println("*Course:" + v1 + " Room:"
									//	+ roomNum);
								break;

							} else {
								solution.put(v1, copyNum);
								//System.out.println("*Course:" + v1 + " Room:"
									//	+ copyNum);
							}
						}

						
						//System.out.println("_________");
					}
				}
			}

		}
		solution.put("room", roomNum);
		return solution;

	}

	/**
	 * Task2
	 * With reputation 
	 * Using adjacent list to prove each combinations
	 * Record the position of all available combination
	 * @return a list of all position
	 **/
	public ArrayList<Integer> getPosition(LinkedHashMap<Integer, ArrayList<Integer>> combinations) {
		ArrayList<Integer> combValue = new ArrayList<Integer>();//Combinations
		ArrayList<String> list = new ArrayList<String>();//Adjacent list
		LinkedHashMap<Integer,String> courseKey = TransKey();
		ArrayList<Integer> pos = new ArrayList<Integer>();//Position in combinations
			
		for(Entry<Integer, ArrayList<Integer>> combination : combinations.entrySet()){
			boolean addable = true;
			//System.out.println("_______________________"+combination.getKey());
			
			combValue = combination.getValue();
			Set<Integer> duplication = new  HashSet<Integer>();
			//Make a duplicate list
			for(int i = 0; i < combValue.size();i++){	
                    duplication.add(combValue.get(i));
				}
			//Compare with Adjacent List
			for(Integer dup : duplication){
				ArrayList<String> checker = new ArrayList<String>();//Checker
				//System.out.println("Duplication: "+ dup);
				int samePos = 0;
				//Adding the same room courses in checker to check
				for(Integer same : combValue){
					samePos++;
					if(same == dup){
						//System.out.println(samePos);
						checker.add(courseKey.get(samePos));//key position in vertex for getting courseName
					 }
					}
				   //System.out.println("Size:"+checker.size());
					//Check the rooms can be allocated together
				   
					for(String ck : checker){
						for (Entry<String, Vertex> entry : vertex.entrySet()) {
							list = entry.getValue().AdjacentList;//Adjacent list
							//there is an path between them
							if(entry.getKey() != ck && list.contains(ck) && checker.contains(entry.getKey())){
								addable = false;
								//System.out.println(list+" VS. "+ ck);
								break;
							 }
						 }
						
					}
					if(addable == false){
						
						//System.out.println("INVALID");
						break;
					}
						
			 }
			 if(addable == true){
				 pos.add(combination.getKey());
			 }	
		}
		return pos;
	}
	
	/**
	 * Task2
	 * Without reputations
	 * Ignoring the allocation without starting at 1
	 * Get 
	 * Getting the [MIN] 
	 * Record the position of all combination which are [MIN]
	 * @return a list of solution
	 **/
	public LinkedHashMap<String, Integer> OptimalSolution(ArrayList<Integer> validCombination, LinkedHashMap<Integer, ArrayList<Integer>> combinations){
		LinkedHashMap<String, Integer> finalSolution = new LinkedHashMap<String, Integer>();
		Queue<ArrayList<Integer>> finder = new LinkedList<ArrayList<Integer>>();//store valid position of combination
		Queue<Integer> mini = new LinkedList<Integer>();//store valid position of combination
		LinkedHashMap<Integer,String> courseKey = TransKey();
		finalSolution.put("room", 0);
		for(Integer i : validCombination ){
			
			int total = 0;	
			int lastTotal = 0;	
			ArrayList<Integer> temp = combinations.get(i);
			//Check starting at 1(smallest room)
			if(temp.contains(1)){
				Set<Integer> Room = new  HashSet<Integer>();
				//Current roomSize
				for(Integer element : temp){
					Room.add(element);
					
				}
				total = Room.size();
				//Last roomSize
				Room = new  HashSet<Integer>();
				if(finder.size()>0){
					for(Integer element2 : finder.peek()){
						Room.add(element2);
					}
					lastTotal = Room.size();
				}
				
				//Compare
				if(total < lastTotal){
					
					finder.poll();//Remove the last min
					mini.poll();//Remove the last min
					finder.add(temp);
					mini.add(total);
				}else if((finder.size()==0)){
					finder.add(temp);
					mini.add(total);
				}
				
				
			}
		}
		//System.out.println(finder.toString());
		finalSolution.put("room", mini.peek());
		for(ArrayList<Integer> index : finder){
			int pos = 0;
			for(Integer i : index){
				pos++;
				finalSolution.put(courseKey.get(pos), i);
			}
		}
		return finalSolution;
	}
	
	
	
	
	

}
