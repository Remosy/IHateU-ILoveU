for i1 = [1:2:100]
 
    i1        
     
end