﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;

namespace prac2
{
    /// <summary>
    /// Summary description for PostcodeFinder
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PostcodeFinder : System.Web.Services.WebService
    {
        ArrayList Addresslist = new ArrayList();
        ArrayList Postlist = new ArrayList();
        int size = 0;
        string[] list;

        [WebMethod]
        public void Load()
        {


            /* ***TEST***
            string FileN = "~/Postcodes.txt";
            string[] line = System.IO.File.ReadAllLines(@Server.MapPath(FileN));
            return line;
             */
            
            try
             {
                // Read file.
                //string[] line = System.IO.File.ReadAllLines(@"\\psf\Home\Documents\Visual Studio 2013\Projects\prac2\prac2\Postcodes.txt");
               
                string FileN = "~/Postcodes.txt";
                string[] line = System.IO.File.ReadAllLines(@Server.MapPath(FileN));
                
                //Get size for Assigning the Size of Return_string: Address
                //Cuz unknown_size of file in the future, converting to string[] later
                size = line.Length;
                
                //Get Postcodes & Adrress from Split_list: list[0][1]
                for (int i = 0; i <size; i++)
                {
                    list = line[i].Split(',');
                    Postlist.Add(list[1]);
                    Addresslist.Add((list[0]));
                }
                
            }
            catch (FileNotFoundException ex){Console.WriteLine(ex);}
            string[] Address = new String[size];
            for (int j = 0; j < size; j++ )
            {
                Address[j] = Addresslist[j].ToString();
            }
        }

        [WebMethod]
        public string[] Loadaddress()
        {
            Load();
            string[] Address = new String[size];
            for (int j = 0; j < size; j++)
            {
                Address[j] = Addresslist[j].ToString();
            }
            return Address;
        }
        
        [WebMethod]
        public string FindP(int num)
        {
            
            Load();
            if ( Postlist.Count < 1)
            {
                return "Null";
            }
            else
            {
               
               
                return Postlist[num].ToString();
               
            }
           

        }
    }
}
