﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using prac3.Service_BookManagement;
using prac3.Book_purchase;
using System.Web.UI.HtmlControls;
using System.Diagnostics;

namespace prac3
{
    public partial class Book1 : System.Web.UI.Page
    {
         List<string> boxid = new List<string>();
         bool For_Search = false;
         int add
         {
             get { return (int)ViewState["Add"]; }
             set { ViewState["Add"] = value; }
         }
        public void createTable( Service_BookManagement.Book[] booklist)
        {
            HtmlTable Mytable = new HtmlTable();
            Mytable.Border = 1;
            Int32 ct = 0;
            //Add Header
            HtmlTableRow row2 = new HtmlTableRow();
            HtmlTableCell headcell1 = new HtmlTableCell("th");
            HtmlTableCell headcell2 = new HtmlTableCell("th");
            HtmlTableCell headcell3 = new HtmlTableCell("th");
            HtmlTableCell headcell4 = new HtmlTableCell("th");
            HtmlTableCell headcell5 = new HtmlTableCell("th");
            HtmlTableCell headcell6 = new HtmlTableCell("th");
            HtmlTableCell headcell7 = new HtmlTableCell("th");
            headcell1.InnerText = "NUM"; row2.Cells.Add(headcell1);
            headcell2.InnerText = "ID"; row2.Cells.Add(headcell2);
            headcell3.InnerText = "Name"; row2.Cells.Add(headcell3);
            headcell4.InnerText = "Author"; row2.Cells.Add(headcell4);
            headcell5.InnerText = "Year"; row2.Cells.Add(headcell5);
            headcell6.InnerText = "Price"; row2.Cells.Add(headcell6);
            headcell7.InnerText = "Stock"; row2.Cells.Add(headcell7);
            Mytable.Rows.Add(row2);
            try
            {
                foreach (Service_BookManagement.Book x in booklist)
                {

                    HtmlTableRow row = new HtmlTableRow();
                    HtmlTableCell cell1 = new HtmlTableCell();
                    HtmlTableCell cell2 = new HtmlTableCell();
                    HtmlTableCell cell3 = new HtmlTableCell();
                    HtmlTableCell cell4 = new HtmlTableCell();
                    HtmlTableCell cell5 = new HtmlTableCell();
                    HtmlTableCell cell6 = new HtmlTableCell();
                    HtmlTableCell cell7 = new HtmlTableCell();

                    ct++;
                    for (int i = 0; i < 7; i++)
                    {

                        cell1.InnerText = ct.ToString();
                        row.Cells.Add(cell1);

                        cell2.InnerText = x.ID;
                        row.Cells.Add(cell2);

                        cell3.InnerText = x.name;
                        row.Cells.Add(cell3);

                        cell4.InnerText = x.author;
                        row.Cells.Add(cell4);

                        cell5.InnerText = x.year.ToString();
                        row.Cells.Add(cell5);

                        cell6.InnerText = "$" + x.price.ToString();
                        row.Cells.Add(cell6);

                        cell7.InnerText = x.stock.ToString();
                        row.Cells.Add(cell7);

                        Mytable.Rows.Add(row);
                    }
                    if (For_Search == true)
                    { Myview2.Controls.Clear(); Myview2.Controls.Add(Mytable); }
                    else
                    {
                        Myview.Controls.Clear();
                        Myview.Controls.Add(Mytable);
                    }
                   

                }
            }
            catch (Exception) { }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
            Service_BookManagement.BookStoreClient book = new Service_BookManagement.BookStoreClient();
            Service_BookManagement.Book[] booklist = book.GetAllBooks();
            createTable(booklist);
            morebook.Style.Add("margin-right", "3em");
            if (!IsPostBack) { this.add = 0; } else { addmore(); }
   
        }

        //ADD
        protected void Button1_Click(object sender, EventArgs e)
        {
            Noti.Text = "";
            Service_BookManagement.BookStoreClient book = new Service_BookManagement.BookStoreClient();
            try
            {
              
                    string ID = AddID.Text;
                    string Name = AddName.Text;
                    string Author = AddAuthor.Text;
                    Int32 year = Convert.ToInt32(AddYear.Text);
                    Single price = Convert.ToInt32(AddPrice.Text);
                    Int32 stock = Convert.ToInt32(AddStock.Text);
                    if ((ID.Trim()).Length > 0 && (Name.Trim()).Length > 0 && (Author.Trim()).Length > 0
                      && year > 0 && price > 0 && stock > 0)
                    {
                        Boolean yes = book.AddBook(ID, Name, Author, year, price, stock);

                        if (yes == true)
                        {
                            Response.Redirect(Request.RawUrl);
                        }
                        else { Noti.Text = "The Book ID has been used, please change !"; }
                    }
                    else { Noti.Text = "The year, price and stock can only be positive number, and please fill in all boxes !"; }
                
            }catch(Exception){}
        }

        //DELETE
        protected void Button2_Click(object sender, EventArgs e)
        {
            Noti.Text = "";
            Service_BookManagement.BookStoreClient book = new Service_BookManagement.BookStoreClient();
            try { 
                 
                 Boolean yes = book.DeleteBook(What_Delete.SelectedValue, Input_Delete.Text);
                 if (yes == true)
                 {
                     
                     Response.Redirect(Request.RawUrl);
                 }
                 else{
                     Noti.Text = "No line has been deleted";
                 }
            }catch(Exception){}
        }

        
        //SEARCH
        protected void Button3_Click(object sender, EventArgs e)
        {
            Noti.Text = "";
            Service_BookManagement.BookStoreClient book = new Service_BookManagement.BookStoreClient();
          try
          {
                string what = What_Search.SelectedValue;
                string input = Input_Search.Text;
                if (input.Trim() == "") { Noti.Text = "Search Nothing ?"; }
                else {
                    
                    Service_BookManagement.Book[] booklist = book.SearchBook(what, input);
                    For_Search = true;
                    createTable(booklist);
                }
                
                


            }
            catch (Exception) {
                Response.Redirect(Request.RawUrl);
           }
        }

        //ADD MORE
        protected void addmore()
        {

            for (int i = 0; i < this.add; i++)
            {
                Label lbl = new Label();
                lbl.Text = " Book Number ";
                lbl.CssClass = "L1";
                More.Controls.Add(lbl);

                TextBox txt = new TextBox();
                txt.Style.Add("margin-right", "3em");
                txt.ID = "morebook" + i.ToString();
                txt.CssClass = "txt";
                More.Controls.Add(txt);

                Label lbl2 = new Label();
                lbl2.Text = " Amount  ";
                lbl2.CssClass = "L2";
                More.Controls.Add(lbl2);

                TextBox txt2 = new TextBox();
                txt2.ID = "moreamount" + i.ToString();
                txt2.CssClass = "txt2";
                More.Controls.Add(txt2);

                More.Controls.Add(new LiteralControl("<br/>"));
            }
        }

        //CAREAT INITIAL TEXTBOXES
        protected void MORE_Click(object sender, EventArgs e)
        {

            Label lbl = new Label();
            lbl.Text = "Book Number";
            lbl.CssClass = "L1";
            More.Controls.Add(lbl);

            TextBox txt = new TextBox();
            txt.Style.Add("margin-right", "3em");
            txt.ID = "morebook" + add.ToString();
            txt.CssClass = "txt";
            More.Controls.Add(txt);

            Label lbl2 = new Label();
            lbl2.Text = "Amount";
            lbl2.CssClass = "L2";
            More.Controls.Add(lbl2);

            TextBox txt2 = new TextBox();
            txt2.ID = "moreamount" + add.ToString();
            txt2.CssClass = "txt2";
            More.Controls.Add(txt2);

            More.Controls.Add(new LiteralControl("<br/>"));
            this.add++;
        }

        //PURCHASE
        protected void P_Click(object sender, EventArgs e)
        {
            float buget = 0;
            int key = 0;
            int value = 0;
            bool done = true;
            String response = "";
            Dictionary<int, int> items = new Dictionary<int, int>();
            List<int> keyBox = new List<int>();
            List<int> valueBox = new List<int>();

            try
            {
                items.Add(Convert.ToInt32(morebook.Text), Convert.ToInt32(moreamount.Text));
                buget = Convert.ToSingle(Buget.Text);

                foreach (Control c in More.Controls)
                {
                    // Debug.WriteLine("TextBox 's ID*** = "+ c.ID);
                    //Get Key
                    if (c is TextBox && c.ID.StartsWith("morebook"))
                    {

                        TextBox morebooks = (TextBox)c;
                        key = Convert.ToInt32(morebooks.Text);
                        //Duplicate Keys
                        if (!keyBox.Contains(key)) { Debug.WriteLine("Key = " + key); keyBox.Add(key); }
                        else { done = false; response = "Please write same books' info in one row"; break; }


                    }
                    //Get Value
                    if (c is TextBox && c.ID.StartsWith("moreamount"))
                    {
                        TextBox moreamounts = (TextBox)c;
                        value = Convert.ToInt32(moreamounts.Text);
                        if (done == true) { valueBox.Add(value); }

                    }
                }

                if (done == true)
                {
                    //Construct Dictionary of Book
                    for (int x = 0; x < keyBox.Count; x++)
                    {
                        items.Add(keyBox[x], valueBox[x]);
                    }
                    bool result;
                    Book_purchase.BookPurchaseClient bp = new Book_purchase.BookPurchaseClient();
                    response = bp.PurchaseInfo(buget, items, out result);


                }

                TextBox4.Text = response;


            }
            //Duplicate Keys
            catch (ArgumentException) { TextBox4.Text = "Same book in same box"; }
            //Empty Boxes
            catch (FormatException) { TextBox4.Text = "Please finish all"; }
        }

        //FRESH
        protected void FRESH_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
  
    }
}