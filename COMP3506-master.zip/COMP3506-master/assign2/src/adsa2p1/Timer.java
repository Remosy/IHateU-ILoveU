package adsa2p1;

public class Timer {
	int Timer1;
	int Timer2;
	public int getTimer1(){
        return Timer1;
    }
	
	public int getTimer2(){
        return Timer2;
    }
}
