package adsa2p1;

import java.util.ArrayList;

public class Timetable {

	//Timetable -> CourseCode + Time
	String courseCode;
	ArrayList<Timer> time = new ArrayList<Timer>();
	
	
	public String GetSourceCode(){
		return courseCode;
	}
	
	public ArrayList<Timer> GetTime(){
	return time;
	}
	
}
