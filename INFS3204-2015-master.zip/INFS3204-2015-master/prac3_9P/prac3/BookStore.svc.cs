﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Diagnostics;

namespace prac3
{

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "BookStore" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select BookStore.svc or BookStore.svc.cs at the Solution Explorer and start debugging.
   
   
    
    public class BookStore : IBookStore
    {
        public string fileName = @"\\psf\Home\Documents\Visual Studio 2013\Projects\prac3\prac3\books.txt";
        public string newFileName = @"\\psf\Home\Documents\Visual Studio 2013\Projects\prac3\prac3\new.txt";
        List<Book> FinalBook;
        //ADD
        Boolean CK_Duplicate = false;
        Boolean CanAdd = true;
        string NewID = "";

        public List<Book> GetAllBooks()
        {
               Book book = new Book();
               try
               {
                   string[] read = File.ReadAllLines(fileName);
                   List<Book> bookinfo = new List<Book>();
                  
                   foreach (string x in read)
                   {
                       string[] list = x.Split(',');
                       // System.Diagnostics.Debug.WriteLine(list[0]);
                       if (CK_Duplicate == true && NewID.Equals(list[0].Replace("[comma]", ",")))
                       {

                           CanAdd = false;
                           break;
                       }
                       else
                       {
                           bookinfo.Add(new Book()
                           {
                               ID = list[0].Replace("[comma]", ","),
                               name = list[1].Replace("[comma]", ","),
                               author = list[2].Replace("[comma]", ","),
                               year = Convert.ToInt32(list[3]),
                               price = Convert.ToSingle(list[4].Substring(1)),
                               stock = Convert.ToInt32(list[5])
                           });
                       }

                   }
                   FinalBook = bookinfo;
                   return bookinfo;
               }catch(Exception){
                   return null;
               }
        }


        public Boolean AddBook(string ID, string Name, string Author, int year, float price, int stock)
        {
            string lines;
            Book newbook = new Book();
          
            ArrayList listOfStrings = new ArrayList();
            
            try
            {
                //Check DUPLICATED ID -->Check in Add
                CK_Duplicate = true;
                NewID = ID;
                List<Book> linesList = GetAllBooks();

                //Other INPUT validation 
                if (CanAdd == true && (Name.Trim()).Length > 0 && (Author.Trim()).Length > 0
                    && year > 0 && price > 0 && stock > 0)
                {
                    NewID = "";//Empty for reusing
                    //Format
                    string m = ",";
                    newbook.ID = ID.Replace(",", "[comma]");
                    newbook.name = Name.Replace(",", "[comma]");
                    newbook.author = Author.Replace(",", "[comma]");
                    newbook.year = year;
                    newbook.price = price;
                    newbook.stock = stock;

                    if (CanAdd == true)
                    {   //ADD NEW --> LIST
                        linesList.Add(newbook);
                       
                        foreach (Book fb in linesList)
                        {
                            lines = fb.ID + m + fb.name + m + fb.author + m + fb.year +
                           m + "$" + fb.price + m + fb.stock;
                            Debug.WriteLine(lines);
                            listOfStrings.Add(lines);//Format same as TEXT file
                            
                        }
                       
                            string[] bList2 = new string[listOfStrings.Count];
                            bList2 = (String[])listOfStrings.ToArray(typeof(string));
                            System.IO.File.WriteAllLines(fileName, bList2);
                            return CanAdd;
                    }
                    else { return CanAdd; }
                }

                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
       
        
        public Boolean DeleteBook(string what, string input)
        {
            int inputNum = 0;
            int inputYear = 0;
            Boolean Delete = true;
            ArrayList bList = new ArrayList();
          
            //INPUT VALIDATION
            switch (what)
            {
                case "Num":
                     try{
                         if ((inputNum = Convert.ToInt32(input)) > 0){
                                 using (System.IO.StreamReader sr = System.IO.File.OpenText(fileName))
                                {
                                        string s = "";
                                        int ct = 0;
                                        while ((s = sr.ReadLine()) != null)
                                        {
                                            string[] list = s.Split(',');
                                            ct++;
                                            //Find Deletion and skip
                                            if(ct != inputNum){ bList.Add(s);}
                                        }
                                        
                                        string[] bList2 = new string[bList.Count];
                                        bList2 = (String[])bList.ToArray(typeof(string));
                                        System.IO.File.WriteAllLines(newFileName, bList2); 
                                 }
                                   //Delete Old file
                                 if (File.Exists(fileName) && File.Exists(newFileName)) {
                                     File.Delete(fileName);
                                     File.Move(newFileName, fileName);
                                 }

                         }else{Delete = false;}
                    }
                    catch(Exception){Delete = false;}
                    break;
                   
                case "Year":
                    try
                    {
                        if ((inputYear = Convert.ToInt32(input)) > 0)
                        {
                            using (System.IO.StreamReader sr = System.IO.File.OpenText(fileName))
                            {
                                string s = "";
                                int ct = 0;
                                while ((s = sr.ReadLine()) != null)
                                {
                                    string[] list = s.Split(',');
                                    ct++;
                                    //Find Deletion and skip
                                    if (Convert.ToInt32(list[3]) != inputYear){bList.Add(s);}
                                    string[] bList2 = new string[bList.Count];
                                    bList2 = (String[])bList.ToArray(typeof(string));
                                    System.IO.File.WriteAllLines(newFileName, bList2);
                                }
                            }
                            //Delete Old file
                            if (File.Exists(fileName) && File.Exists(newFileName))
                            {
                                File.Delete(fileName);
                                File.Move(newFileName, fileName);
                            }
                        }
                        else
                        {Delete = false;}
                    }
                    catch (Exception) {
                        return false;
                    }
                    break;
                
                case "ID":
                    try { 
                        if((input.Trim()).Length>0){
                            using (System.IO.StreamReader sr = System.IO.File.OpenText(fileName))
                            {
                                string s = "";
                                int ct = 0;
                                while ((s = sr.ReadLine()) != null)
                                {
                                    string[] list = s.Split(',');
                                    ct++;
                                    //Find Deletion and skip
                                    if (!list[0].Equals(input)){ bList.Add(s); }
                                    string[] bList2 = new string[bList.Count];
                                    bList2 = (String[])bList.ToArray(typeof(string));
                                    System.IO.File.WriteAllLines(newFileName, bList2);
                                }
                            }
                            //Delete Old file
                            if (File.Exists(fileName) && File.Exists(newFileName))
                            {
                                File.Delete(fileName);
                                File.Move(newFileName, fileName);
                            }
                        }
                        else{Delete = false;}
                    }
                    catch(Exception){Delete = false;}
                    break;
            }


            return Delete; 
        }
        

        
        public List<Book> SearchBook( string what, string input)
        {
            List<Book> booklist = GetAllBooks();
            List<Book> booklist2 = new List<Book>();
            
            try
            {
                
                switch (what) { 
                    case "Year":
                            int Syear = Convert.ToInt32(input);
                            foreach (Book mybook in booklist) {
                               // System.Diagnostics.Debug.WriteLine(booklist2.Count);
                                if (mybook.year == Syear) {
                                    booklist2.Add(mybook);
                                }
                            }

                            break;
                  
                    case "Author":
                            foreach (Book mybook in booklist)
                            {
                                if(mybook.author.ToUpper().Contains(input.Trim().ToUpper())){
                                    booklist2.Add(mybook);
                                }
                            }
                            break;
                     
                    case "Name":
                            foreach (Book mybook in booklist)
                            {
                                if (mybook.name.ToUpper().Contains(input.Trim().ToUpper()))
                                {
                                    booklist2.Add(mybook);
                                }
                            }
                            break;

                    case "ID":
                            foreach (Book mybook in booklist)
                            {
                                if (mybook.ID.Equals(input.Trim()))
                                {
                                    booklist2.Add(mybook);
                                }
                            }
                            break;
                }
                return booklist2;
            }
            catch (Exception)
            {
                return null;
            }
        }

        

       
    }
}

