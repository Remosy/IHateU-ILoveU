package adsa2p1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Map.Entry;

public class ProblemOne {

	static ArrayList<Timetable> myTimelist = new ArrayList<Timetable>();

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		String filename = args[0];
		String mymethods = args[1];
		//System.out.println("Running:" + mymethods);
		//long startTime = System.currentTimeMillis();
		if (mymethods.equals("greedy")) {
			Greedy(filename + ".in");
		} else if(mymethods.equals("optimal")){
			Optimal(filename + ".in");
		}
		//long endTime = System.currentTimeMillis();
		//long totalTime = endTime - startTime;
		//System.out.println("RunningTime:" + totalTime);
		 
	}

	/**
	 * Task1 & Task2 STEP1
	 * 
	 * @return A List of Timetable from input file
	 * @throws Exception
	 */

	public static ArrayList<Timetable> getInfo(String fileName)
			throws Exception {

		try {
			ArrayList<Timetable> timelist = new ArrayList<Timetable>();
			// String fileName =
			// "/Users/adaremasy13/Desktop/Mymymy/comp3506Assign/assign2/src/Task1/input.in";
			// Read File
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String data;
			// Get total line
			int totalNum = Integer.parseInt(reader.readLine());
			//System.out.println("Total Line:" + totalNum);
			String keyPattern = "\\w{4}\\d{4}";
			String valuePattern = "^\\d+";
			boolean Addable = true;
			String[] temp;
			// Make a object with input
			while ((data = reader.readLine()) != null) {
				Timetable timetable = new Timetable();
				// System.out.println(data);
				temp = data.split(" ");
				// Adding CourseCode
				if (temp[0].matches(keyPattern)) {
					timetable.courseCode = temp[0];
					// System.out.println("Course: "+ timetable.courseCode);
				} else {
					Addable = false;
				}
				// Adding Time
				if (Addable != false) {
					for (int i = 1; i < temp.length; i += 2) {
						Timer timer = new Timer();
						if (temp[i].matches(valuePattern)) {
							timer.Timer1 = Integer.parseInt(temp[i]);
							timer.Timer2 = Integer.parseInt(temp[i + 1]);
							timetable.time.add(timer);
							// System.out.println("Value#" + i + "= " + temp[i]
							// + "," + temp[i + 1]);
						} else {
							Addable = false;
							break;
						}
					}
					/*
					 * for (Timer t : timetable.time) { System.out.println("(" +
					 * t.Timer1 + "," + t.Timer2 + ")"); }
					 */
					// Add course&timetable
					if (Addable != false) {
						timelist.add(timetable);
						// System.out.println("Done" + timelist.size());
					}
				}
			}
			reader.close();
			if (timelist.size() == totalNum) {
				return timelist;
			} else {
				return null;
			}
		} catch (Exception e) {
			// System.out.println("Not Done");
			throw new Exception(e);
		}
	}

	/**
	 * Task1 & Task2 STEP2
	 * 
	 * @return Construct a Graph
	 */
	public static Graph representGraph(ArrayList<Timetable> timetable) {
		LinkedHashMap<String, Vertex> graphList = new LinkedHashMap<String, Vertex>();
		for (Timetable timetable1 : myTimelist) {
			// System.out.println(timetable1.courseCode);
			graphList.put(timetable1.courseCode, null);
			Vertex vertex = new Vertex();
			for (Timetable timetable2 : myTimelist) {
				String checker2 = null;
				for (Timer t1 : timetable1.time) {
					for (Timer t2 : timetable2.time) {
						int A = t1.Timer1;
						int X = t2.Timer1;
						int B = t1.Timer2;
						int Y = t2.Timer2;
						String Course1 = timetable1.courseCode;
						String Course2 = timetable2.courseCode;
						if (((A >= X && A < Y) || (X >= A && X < B))
								&& Course1 != Course2 && Course2 != checker2) {
							checker2 = Course2;
							vertex.AdjacentList.add(Course2);
						}
					}
				}
			}
			graphList.put(timetable1.courseCode, vertex);
		}
        
		/*
		for (Entry<String, Vertex> entry : graphList.entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = "
					+ entry.getValue().AdjacentList);
		}*/

		Graph g = new Graph(graphList);
		return g;
	}

	/**
	 * Task1 STEP3 Construct a graph by the adjacent list and Graph class Using
	 * method(getNonEdge) from Graph class and decide if there is an edge
	 * between two vertices if there is no path, then allocate theses two
	 * vertices together in a room
	 * 
	 * @return A list of room allocation solution
	 */
	public static void Greedy(String filename) {

		try {
			myTimelist = getInfo(filename);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Graph graphList = representGraph(myTimelist);
		LinkedHashMap<String, Integer> s = new LinkedHashMap<String, Integer>();
		s = graphList.getNonEdge();
		/*
		 * for (Entry<String, Integer> entry : s.entrySet()) {
		 * System.out.println(entry.getKey() + ", " + entry.getValue()); }
		 */
		OutPut(s,filename);
	}
	
	/**
	 * Task2 STEP3
	 * Get the input will be put to generate whole possible combinations
	 * @parameter total room
	 * @return A list of room input
	 * 
	 */
	public static ArrayList<Integer> Combination(int total){
		ArrayList<Integer> in = new ArrayList<Integer>();
		for(int x = 1; x <= total; x++){
			//System.out.println(x);
			in.add(x);
		}		
		return in;
	}
	
	/**
	 * Task2 STEP4
	 * Get the whole possible room allocation combinations
	 * 
	 * @return A list of room allocation combinations
	 */
	
	
	public static LinkedHashMap<Integer, ArrayList<Integer>> Combination_Rec( ArrayList<Integer> in, int count, int ct, LinkedHashMap<Integer, ArrayList<Integer>> solution, int size){
		LinkedHashMap<Integer, ArrayList<Integer>> roomcom = new LinkedHashMap<Integer, ArrayList<Integer>>();
		//Until there are no more number element need to be combined
				//Return the final solution
		
				if(count ==0){
					//System.out.println("End");
					return solution;
				}		
		if(solution.size() == 0){//Initial 
			for (Integer i2 : in) {
	            ArrayList<Integer> temp2 = new ArrayList<Integer>();
	            temp2.add(i2);
	            //System.out.println(temp2.toString());
	            solution.put(ct++, temp2);
	            //System.out.println("INIT:"+ct);
	        }
			return Combination_Rec(in,count-1,ct,solution,size);
		}else{
			
			for(ArrayList<Integer> x : solution.values()){
				boolean addable = true;
				for(Integer i : in){
					Set<Integer> tmpset = new  HashSet<Integer>();	
					ArrayList<Integer> temp = new ArrayList<Integer>();
					temp.addAll(x);
					temp.add(i);
					tmpset.addAll(temp);
					//System.out.println(tmpset.toString()+temp.toString());
					int old = 0;
					int current = 0;
					
					for(Integer inset : tmpset){
						addable = true;
						old = current;
						current = inset;
						if(current != old + 1 && temp.size() == size){
							addable = false;
							break;
						}
						//System.out.println("old"+old+"current"+current);
					}
					//System.out.println("Bool---"+addable);
					if(addable == true){
						//System.out.println(": "+temp);
						roomcom.put(ct++,temp);
					}
					
				}
			}
			return Combination_Rec(in,count-1,ct,roomcom,size);
		}	
	}
	
	
	

	/**
	 * Task2 STEP3 Construct a graph by the adjacent list and Graph class Using
	 * method() from Graph class and decide if there is an edge between two
	 * vertices if there is no path, then allocate theses two vertices together
	 * in a room
	 * 
	 * @return A list of room allocation solution
	 */
	public static void Optimal(String filename) {
		ArrayList<Integer> input = new ArrayList<Integer>();
		LinkedHashMap<Integer, ArrayList<Integer>> combination = new LinkedHashMap<Integer, ArrayList<Integer>>();
		try {
			myTimelist = getInfo(filename);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Graph graphList = representGraph(myTimelist);
		int total = graphList.getSize();
		//System.out.println("Total:"+total);
		input = Combination(total);
		combination = Combination_Rec(input, input.size(), 0,new LinkedHashMap<Integer, ArrayList<Integer>>(), input.size());
		//System.out.println(combination.toString());
		//System.out.println(combination.size());
		ArrayList<Integer> res = graphList.getPosition(combination); 
		//System.out.println(res.toString());
		LinkedHashMap<String, Integer> s = graphList.OptimalSolution(res,combination);
		/*
		 for (Entry<String, Integer> entry : s.entrySet()) {
		 System.out.println(entry.getKey() + ", " + entry.getValue()); }
		 */
		 OutPut(s,filename);
	}

	/**
	 * Task1 & Task2 STEP4 Generate an output file
	 */
	public static void OutPut(LinkedHashMap<String, Integer> solution, String filename) {
		BufferedWriter out;
		FileWriter fstream;
		try {
			fstream = new FileWriter(filename.replace(".in", ".out"));
			out = new BufferedWriter(fstream);
			Iterator<Entry<String, Integer>> it = solution.entrySet()
					.iterator();
			while (it.hasNext()) {
				// the key/value pair is stored here in pairs
				Entry<String, Integer> pairs = it.next();
				if (pairs.getKey() != "room") {
					// System.out.println("Value is " + pairs.getValue());
					out.write(pairs.getKey() + " " + pairs.getValue() + "\n");
				} else {
					out.write(pairs.getValue() + "\n");
				}
			}
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//System.out.println(solution);
	}

}
