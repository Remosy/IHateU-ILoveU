function y = sgn(x)
%SGN   Sign
%   SGN(X) returns the sign of a value X.
%   It can be either negative, positive, or 0 if X == 0.
    if x < 0
 
y = -1;
 
    elseif x > 0
 
y = 1;
 
    else
 
y = 0;
 
end