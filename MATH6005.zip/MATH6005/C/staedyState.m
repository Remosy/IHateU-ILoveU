T = []
M = [0; 0; 0]
I = [1 0 0 ;0 1 0 ; 0 0 1 ]
C =horzcat(T'-I,M)
C(3,:)=1
rref(C)