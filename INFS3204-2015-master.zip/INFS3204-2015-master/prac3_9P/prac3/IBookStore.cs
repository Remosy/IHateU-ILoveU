﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace prac3
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IBookStore" in both code and config file together.
    [DataContract]
    public class Book{
        [DataMember]
        public string ID;
        [DataMember]
        public string name;
        [DataMember]
        public string author;
        [DataMember]
        public int year;
        [DataMember]
        public float price;
        [DataMember]
        public int stock;

    }
    

    [ServiceContract]
    public interface IBookStore
    {
       
        [OperationContract]
        List<Book> GetAllBooks();
        
        [OperationContract]
        Boolean AddBook(string ID, string Name, string Author, int year, float price, int stock);
        
        [OperationContract]
        Boolean DeleteBook(string what, string input);
     
        [OperationContract]
        List<Book> SearchBook(string what, string input);

            

       

    }

    /*
    [MessageContract]
    public class SearchBook
    {
        [MessageHeader]
        public string ID;
        [MessageHeader]
        public string Name;
        [MessageHeader]
        public string author;
        [MessageHeader]
        public int year;
        [MessageHeader]
        public float price;
        [MessageHeader]
        public int stock;

    }*/
    
    
}
