package adsa2p1;

@SuppressWarnings("serial")
public class courseException extends Exception {
	public courseException(String message) {
		super(message);
	}
}
