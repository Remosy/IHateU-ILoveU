﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace prac2
{
    /// <summary>
    /// Summary description for ZodiacByName
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ZodiacByName : System.Web.Services.WebService
    {

        [WebMethod]
        public string FindName(int Mon, int Date)
        {
            string tmp = "";
            try
            {
                new DateTime(1900, Mon, Date);

            }
            catch (Exception)
            {
                return "Not Found";
            }

            DateTime user = new DateTime(1900, Mon, Date);

            List<string> stars = new List<string>{
                            "Aquarius","Pisces","Aries",
                            "Taurus","Gemini","Cancer",
                            "Leo","Virgo", "Libra",
                            "Scorpio","Sagittarius","Capricorn", 
                              };

            int[,] gap ={
                        {0,1},{2,3},{4,5},//0[Aquanrius],1[Piscs],2[Aries]
                        {6,7},{8,9},{10,11},//3[Taurus],4["Gemini],5[Cancer]
                        {12,13},{14,15},{16,17},//6[Leo],7[Virgo],8[]Libra]
                        {18,19},{20,21},{22,23},//9[Scorpio],10[Sagitarius],11[capricorn]
                        };

            List<DateTime> stardate = new List<DateTime>{

         new DateTime(1900, 1, 21),
         new DateTime(1900, 2, 19),//Aquanrius

         new DateTime(1900, 2, 20),
         new DateTime(1900, 3, 20),//Piscs

         new DateTime(1900, 3, 21),
         new DateTime(1900, 4, 20),//Aries
       
         new DateTime(1900, 4, 21),
         new DateTime(1900, 5, 21),//Taurus

         new DateTime(1900, 5, 22),
         new DateTime(1900, 6, 21),//Gemini

         new DateTime(1900, 6, 22),
         new DateTime(1900, 7, 22),//Cancer

         new DateTime(1900, 7, 23),
         new DateTime(1900, 8, 22),//Leo

         new DateTime(1900, 8, 23),
         new DateTime(1900, 9, 23),//Virgo

         new DateTime(1900, 9, 24),
         new DateTime(1900, 10, 23),//Libra

         new DateTime(1900, 10, 24),
         new DateTime(1900, 11, 22),//Scopio

         new DateTime(1900, 11, 23),
         new DateTime(1900, 12, 21),//Sag

         new DateTime(1900, 12, 22),
         new DateTime(1900, 1, 20),//Capricorn

        
        };


            

            //Uniq Condition
            if (Mon == 1)
            {
                if (user > stardate[11])
                {
                    tmp = stars[0];
                }
                else
                {
                    tmp = stars[0];
                }

            }
            else
            {
                                    //gap(1st condition,2nd condition)
                if (user >= stardate[gap[Mon - 2, 0]] && user <= stardate[gap[Mon - 2, 1]])
                {
                    tmp = stars[Mon - 2];
                }
                else
                {
                    tmp = stars[Mon - 1];
                }
            }
            return tmp;
                   
                /*
                if ((Mon ==3 && Date>=21 && Date <= 31 ) || (Mon == 4 && Date <= 20 && Date >= 1) && Mon>=0 && Date >= 0){
                    return "Aries";
                }
            
                else if ((Mon == 4 && Date >= 21 && Date <= 30) || (Mon == 5 && Date <= 20 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Taurus";
                }

                else if ((Mon == 5 && Date >= 22 && Date <= 31) || (Mon == 6 && Date <= 21 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Gemini";
                }

                else if ((Mon == 6 && Date >= 22 && Date <= 30) || (Mon == 7 && Date <= 22 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Cancer";
                }

                else if ((Mon == 7 && Date >= 23 && Date <= 31) || (Mon == 8 && Date <= 22 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Leo";
                }

                else if ((Mon == 8 && Date >= 23 && Date <= 31) || (Mon == 9 && Date <= 23 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Virgo";
                }

                else if ((Mon == 9 && Date >= 24 && Date <= 30) || (Mon == 10 && Date <= 23 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Libra";
                }

                else if ((Mon == 10 && Date >= 24 && Date <= 30) || (Mon == 11 && Date <= 22 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Scorpio";
                }

                else if ((Mon == 11 && Date >= 23 && Date <= 30) || (Mon == 12 && Date <= 21 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Sagittarius";
                }

                else if ((Mon == 12 && Date >= 22 && Date <= 31) || (Mon == 1 && Date <= 20 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Capricorn";
                }

                else if ((Mon == 1 && Date >= 21 && Date <= 30) || (Mon == 2 && Date <= 19 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Aquarius";
                }
                else if ((Mon == 2 && Date >= 20 && Date <= 28) || (Mon == 3 && Date <= 20 && Date >= 1) && Mon >= 0 && Date >= 0)
                {
                    return "Pisces";
                }
                else {
                    return "Not Found";
                }*/


                }
            }
        }
    

    
