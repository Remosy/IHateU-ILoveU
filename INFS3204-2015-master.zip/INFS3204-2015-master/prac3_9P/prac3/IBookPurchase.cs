﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace prac3
{
    [MessageContract]
    public class BookPurchaseInfo
    {

        [MessageHeader]
        public float buget;
        [MessageHeader]
        public Dictionary<int, int> items;

    }


    [MessageContract]
    public class BookPurchaseResponse
    {
       
        [MessageHeader]
        public bool result;
        [MessageHeader]
        public string response;

    }

   

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IBookPurchase" in both code and config file together.
    [ServiceContract]
    public interface IBookPurchase
    {
        [OperationContract]
         BookPurchaseResponse PurchaseInfo(BookPurchaseInfo bookpurchaseinfo);

    }

}
