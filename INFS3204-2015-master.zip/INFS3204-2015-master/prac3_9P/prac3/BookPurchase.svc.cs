﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Diagnostics;
using prac3.Service_BookManagement;
using System.IO;

namespace prac3
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "BookPurchase" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select BookPurchase.svc or BookPurchase.svc.cs at the Solution Explorer and start debugging.
    public class BookPurchase : IBookPurchase
    {

        public string fileName = @"\\psf\Home\Documents\Visual Studio 2013\Projects\prac3\prac3\books.txt";
        public List<Book> GetBooks()
        {
            Book book = new Book();
            try
            {
                string[] read = File.ReadAllLines(fileName);
                List<Book> bookinfo = new List<Book>();

                foreach (string x in read)
                {
                    string[] list = x.Split(',');
                    // System.Diagnostics.Debug.WriteLine(list[0]);

                    bookinfo.Add(new Book()
                    {
                        ID = list[0].Replace("[comma]", ","),
                        name = list[1].Replace("[comma]", ","),
                        author = list[2].Replace("[comma]", ","),
                        year = Convert.ToInt32(list[3]),
                        price = Convert.ToSingle(list[4].Substring(1)),
                        stock = Convert.ToInt32(list[5])
                    });

                }
               
                return bookinfo;
            }
            catch (Exception)
            {
                return null;
            }
        }


        public BookPurchaseResponse PurchaseInfo(BookPurchaseInfo bookpurchaseinfo)
        {

            float buget = bookpurchaseinfo.buget;
            Dictionary<int, int> item = bookpurchaseinfo.items;
            List<int> index = new List<int>();//Key list
            List<int> NumofBook = new List<int>();//Num of book
            float total = 0;
            string response;
            bool result = true;
            bool enoughStock = true;
            bool exist = true;
           
            
            //Get index
            foreach(int key in item.Keys){index.Add(key);}
            //Get NumofBook
            foreach(int nob in item.Values){NumofBook.Add(nob);}

            //Get total price from Booklist
            List<Book> booklist = GetBooks();
            for(int i = 0; i < index.Count; i++){
               // Debug.WriteLine("index:"+index[i]);
                if (index[i] == 0) { exist = false; break; }
                for(int j = 0; j < index[i]; j++){
                //Count Price
                   // Debug.WriteLine("J:" + j);
                   
                 if(j == index[i]-1){
                     if (j > booklist.Count-1) { Debug.WriteLine("No exist"); exist = false; break; }
                     else{
                        // Debug.WriteLine("Bookprice:" + booklist[j].price);
                         Debug.WriteLine("Break?");
                         if (NumofBook[i] > booklist[j].stock)
                         {
                             enoughStock = false;
                             break;
                         }
                         total += booklist[j].price * NumofBook[i];
                     }
                    
                 }
               
                    
                }
            }
            

            if(total > buget)
            {
               // Debug.WriteLine("RB");
                //Result A
                result = false;
                response = "Not enough money" + total;
            }else if (enoughStock == false)
            {
                //Debug.WriteLine("RC");
                //Result B
                result = false;
                response = "Not enough stock";
               // response = (buget - total).ToString();
            }else if(exist == false)
            {
                //Result C
                result = false;
                response = "The book is not exist";
            }
            else {
                //Result D
                response = (buget - total).ToString();
            }

            
            //Return
            BookPurchaseResponse bpr = new BookPurchaseResponse();
            bpr.response = response;
            //bpr.response = "**";
            bpr.result = result;
            return bpr;
           

        }

       
    }
}
