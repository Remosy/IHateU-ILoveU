x = -30:0.2:30;
y1 = X.^2;
y2=-x.^2; 
y3=(x.^2).*sin(x);
plot(x,y1,x,y2,x,y3);
 
title('Comparing functions')
xlabel('x')
ylabel('y')
legend('y1=x^2','y2=-x^2','y3=x^2 sin(x)')
 
print('module04.png','-dpng')