load bris_temp % loads temperature variables
clf; % clears any existing figures
plot(1:12, temp10, 'r', 1:12, temp11,'m',1:12, temp12,'b',1:12, temp13,'g');
 
% some axes formatting for the x-axis
xlim([1 12])
set(gca, 'XTick', 1:12)
set(gca, 'XTickLabel', {'Jan','Feb','Mar','Apr'...
    ,'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'})
 
% labelling axes and legend
title('Brisbane whole year temperatures of 2010, 2011, 2012, 2013')
xlabel('Month')
ylabel('Temperature  ^{\circ}c')
legend('2010','2011','2012','2013')

 print('module03.png','-dpng')