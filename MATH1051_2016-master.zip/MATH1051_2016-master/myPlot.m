% myPlot.m plots the function y(x)=sinx
x = linspace(-pi, pi,20);
y = 3*cos(x);
plot(x,y,'*r:')
text(-pi/2,3*cos(-pi/2),'3*cos(-pi/2)=0')
text(0,3*cos(0),'3*cos(0)=3')
text(pi/2,3*cos(pi/2),'3*cos(pi/2)=0')
axis equal
grid on
set(gcf,'color','white')