﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prac3
{
    interface Array<T1, T2>
    {
    }
}
