﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prc4.Models
{
   
    public class Player
    {
        public String RegistrationID{get; set;}
        public String Firstname{get; set;}
        public String Lastname { get; set; }
        public String Teamname { get; set; }
        public DateTime Dateofbirth { get; set; }

    }
}