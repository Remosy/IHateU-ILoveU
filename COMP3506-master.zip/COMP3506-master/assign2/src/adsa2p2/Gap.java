package adsa2p2;

import java.util.ArrayList;

public class Gap {
	 ArrayList<Integer> gap = new ArrayList<Integer>();
     
}
