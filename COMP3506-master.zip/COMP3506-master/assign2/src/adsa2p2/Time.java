package adsa2p2;


public class Time {
	  
       int time = 0;
       
}
