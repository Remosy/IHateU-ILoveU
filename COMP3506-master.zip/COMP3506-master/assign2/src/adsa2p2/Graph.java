package adsa2p2;


public class Graph{
	 Flappyinfo flainfo = new Flappyinfo();
	 int n = flainfo.n;
	 int m = flainfo.m;
	 int Vertex[][] = new int[n][m];
	  
	  /**
		 * Add 8 to matrix as pipe
		 * @return
		 **/
	 public Graph(int[][] myvertex) {
			this.Vertex = myvertex;
		}
	  
	  
	    
}
