package adsa2p2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class ProblemTwo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String filename = args[0];
		//long startTime = System.currentTimeMillis();
		Play(filename + ".in");
		//long endTime = System.currentTimeMillis();
		//long totalTime = endTime - startTime;
		//System.out.println("RunningTime:" + totalTime);
		// String fileName =
		// "/Users/adaremasy13/Desktop/Mymymy/comp3506Assign/assign2/src/Task2/bird.in";
	}

	private static void Play(String filename) {
		Flappyinfo fla = new Flappyinfo();
		try {

			fla = getInfo(filename);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(fla.initialAlt);
		Graph gra = RepresentGraph(fla);
		//System.out.println(gra.Vertex.length);
		FindAllPath(fla, gra);
	}

	/**
	 * STEP1 Read File and build an object --> Flappyinfo
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Flappyinfo getInfo(String fileName) throws Exception {
		int ct = 0;// count line
		Flappyinfo flappyinfo = new Flappyinfo();
		try {
			// String fileName =
			// "/Users/adaremasy13/Desktop/Mymymy/comp3506Assign/assign2/src/Task2/bird.in";
			// Read File
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String data;
			int[] n_m_k = new int[3];// 1st line
			int initial = 0;// initial altitude 2nd line
			String[] temp;

			// Make a flappyinfo object with input
			while ((data = reader.readLine()) != null) {
				ct++;
				if (ct == 1) {
					temp = data.split(" ");
					for (int x = 0; x < temp.length; x++) {
						n_m_k[x] = Integer.parseInt(temp[x]);
					}
					flappyinfo.n = n_m_k[0];
					flappyinfo.m = n_m_k[1];
					flappyinfo.k = n_m_k[2];
				} else if (ct == 2) {
					initial = Integer.parseInt(data);
					flappyinfo.initialAlt = initial;
				} else if (ct == 3) {
					temp = data.split(" ");
					for (int x = 0; x < temp.length; x++) {
						flappyinfo.X_action.add(Integer.parseInt(temp[x]));
					}
				} else if (ct == 4) {
					temp = data.split(" ");
					for (int x = 0; x < temp.length; x++) {
						flappyinfo.Y_action.add(Integer.parseInt(temp[x]));
					}
				} else if (ct > 4) {
					Gap gap = new Gap();
					Time time = new Time();
					temp = data.split(" ");
					time.time = Integer.parseInt(temp[0]);
					gap.gap.add(Integer.parseInt(temp[1]));
					gap.gap.add(Integer.parseInt(temp[2]));
					flappyinfo.Pipe.put(time, gap);
				}
			}
			/*
			 * for (Entry<Time, Gap> entry : flappyinfo.Pipe.entrySet()) {
			 * System.out.println("Key = " + entry.getKey().time + ", Value = "
			 * + entry.getValue().gap); }
			 */
			reader.close();
			RepresentGraph(flappyinfo);
		} catch (Exception e) {
			// System.out.println("Not Done");
			throw new Exception(e);
		}
		return flappyinfo;
	}

	/**
	 * STEP2 Implementing these data with Graph
	 * 
	 * @throws Exception
	 */
	public static Graph RepresentGraph(Flappyinfo info) {
		int n = info.n;
		int m = info.m;
		int x_axix = n + 1;
		int y_axix = m + 1;
		int Vertex[][] = new int[y_axix][x_axix];
		LinkedHashMap<Time, Gap> pipe = info.Pipe;
		Gap gap = new Gap();
		for (Time t : pipe.keySet()) {
			for (int i = 0; i < n; i++) {

				if (t.time == i) {
					gap = pipe.get(t);
					int top = y_axix - gap.gap.get(1);
					int buttom = y_axix - gap.gap.get(0) - 1;
					// System.out.println("Top= "+top);
					// System.out.println("Buttom= "+buttom);
					// Adding top pipe
					for (int ti = 0; ti < top; ti++) {
						Vertex[ti][i] = 4;
					}
					// Adding buttom pipe
					for (int bi = buttom; bi < y_axix; bi++) {
						Vertex[bi][i] = 4;
					}
				}

			}
		}

		Graph g = new Graph(Vertex);
		return g;
	}

	/**
	 * STEP3 Get a path with optimal method from the combination
	 */
	public static void FindAllPath(Flappyinfo fla, Graph g) {
		ArrayList<Integer> X_action = fla.X_action;
		ArrayList<Integer> Y_action = fla.Y_action;
		//System.out.println("X:" + X_action.toString());
		//System.out.println("Y:" + Y_action.toString());
		int start = fla.initialAlt;
		LinkedHashMap<Integer, ArrayList<Integer>> possiblepath = FindPathAccessable(
				X_action, Y_action, g, start);
		ArrayList<ArrayList<Integer>> combination = Find_Rec(
				new ArrayList<ArrayList<Integer>>(), possiblepath, fla.m);
		//Have not finished yet
		/*
		for(int x = 0; x < g.Vertex.length; x++){
			for(int y = 0; y < g.Vertex[x].length; y++){
				System.out.print(g.Vertex[x][y]+" ");
			}
			System.out.println();
		}*/
	}

	/**
	 * STEP4 Get all accesable path
	 * 
	 */
	public static LinkedHashMap<Integer, ArrayList<Integer>> FindPathAccessable(
			ArrayList<Integer> X_action, ArrayList<Integer> Y_action, Graph g,
			int start) {
		LinkedHashMap<Integer, ArrayList<Integer>> possible = new LinkedHashMap<Integer, ArrayList<Integer>>();
		// looking horizontally -->collect all possible value at time with
		// limitation(pipe)

		for (int v = 0; v < g.Vertex.length; v++) {
			ArrayList<Integer> pos = new ArrayList<Integer>();
			if (v == 0) {// Initial
				pos.add(g.Vertex.length - start - 1);

			} else {
				for (int u = 0; u < g.Vertex.length; u++) {
					if (g.Vertex[u][v] != 4) {
						pos.add(u);

					}
				}
			}
			possible.put(v, pos);
		}
        /*
		for (Entry<Integer, ArrayList<Integer>> entry : possible.entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = "
					+ entry.getValue());
		}*/
		return possible;
	}

	/**
	 * STEP5 Get all accesable path in combinations from STEP4
	 * 
	 */
	public static ArrayList<ArrayList<Integer>> Find_Rec(
			ArrayList<ArrayList<Integer>> combination,
			LinkedHashMap<Integer, ArrayList<Integer>> possible, int level) {

		if (level == 0) {
			return combination;
		}
		if (combination.size() == 0) {
			for (Entry<Integer, ArrayList<Integer>> entry : possible.entrySet()) {
				ArrayList<Integer> com = new ArrayList<Integer>();
				com.add(entry.getValue().get(0));
				combination.add(com);
			}
			// return Find_Rec(combination, possible, level);//level++

		}

		// return Find_Rec(combination, possible, level);//level++
		return combination;
	}

	public static void OutPut(LinkedHashMap<String, Integer> solution,
			String filename) {
		BufferedWriter out;
		FileWriter fstream;
		try {
			fstream = new FileWriter(filename.replace(".in", ".out"));
			out = new BufferedWriter(fstream);
			Iterator<Entry<String, Integer>> it = solution.entrySet()
					.iterator();
			while (it.hasNext()) {
				// the key/value pair is stored here in pairs
				Entry<String, Integer> pairs = it.next();
				if (pairs.getKey() == "level") {
					// System.out.println("Value is " + pairs.getValue());
					out.write(pairs.getValue() + "\n");
				} else {
					out.write(pairs.getValue() + "\n");
				}
			}
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//System.out.println(solution);
	}

}
