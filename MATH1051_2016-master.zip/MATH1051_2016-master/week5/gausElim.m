%gausElim.m
 
% create matrices A and b, 
%ready for computing Ax=b
A = [1 1 -3;-3 -3 3;-1 -2 1];
b = [10 -12 -4].'; 
% augment the matrices 
%using concatenation
Ab_aug = [A b]
% use the RREF function to 
% do row reduction on (A|b)
rowRed = rref(Ab_aug)
% find the nullspace of the matrix A
nullspace = null(A, 'r')