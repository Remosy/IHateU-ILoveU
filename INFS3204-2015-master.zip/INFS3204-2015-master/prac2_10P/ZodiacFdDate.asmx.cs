﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Services;
using System.Collections;

namespace prac2
{
    /// <summary>
    /// Summary description for ZodiacByDate
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
   //System.Web.Script.Services.ScriptService]
    public class ZodiacByDate : System.Web.Services.WebService
    {

       

        [WebMethod]
        public string FindDate(string name)
        {
            List<string> stars = new List<string>{
                              
                
                                "Aquarius","Aries",
                                "Cancer", "Capricorn",
                                "Gemini","Leo",
                                "Libra","Pisces",
                                "Sagittarius","Scorpio",
                                "Taurus","Virgo",
                 
        };
           
           
            ArrayList stardate = new ArrayList{
                                "01/21-02/19","03/21-04/20",
                                "06/22-07/22", "12/22-01/20",
                                "05/22-06/21","07/23-08/22",
                                "09/24-10/23","02/20-03/20",
                                "11/23-12/21","10/24-11/22",
                                "04/21-05/21","08/23-09/23",
        };


        stars.Sort();  
          int date_index = stars.BinarySearch(name);

          if (date_index < 0) {
              return "Not Found";
             
          }else{
               
               return stardate[date_index].ToString();
          }
            

            /*
            if (name =="Aries"){

                return "03/21-04/20";

            } else if (name == "Taurus")
            {
                return "04/21 - 05/21";
            }
            else if (name == "Gemini")
            {
                return "05/22-06/21";
            }
            else if (name == "Cancer")
            {
                return "6/22-07/22";
            }
            else if (name == "Leo")
            {
                return "07/23-08/22";
            }
            else if (name == "Virgo")
            {
                return "08/23-09/23";
            }
            else if (name == "Libra")
            {
                return "09/24-10/23";
            }
            else if (name == "Scorpio")
            {
                return "10/24-11/22";
            }
            else if (name == "Sagittarius")
            {
                return "11/23-12/21";
            }
            else if (name == "Capricorn")
            {
                return "12/22-01/20";
            }
            else if (name == "Aquarius")
            {
                return "01/21-02/19";
            }
            else if (name == "Pisces")
            {
                return "02/20-03/20";
            }
            else
            {
                return "Not Found";
            }          
         */  
        }

        

    }
}
