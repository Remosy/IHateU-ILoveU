w = [6; 2];
v = [6; 6];
p = (dot(v,w)/(norm(v))^2)*v;
% plotting a line from 0,0 to 6,2, from 0,0 to 6,6, and the projection of vector v and vector w
plot([0,w(1)],[0,w(2)],'r',[0,v(1)],[0,v(2)],'g',[0,p(1)],[0,p(2)],'b--') 
axis([0 7 0 7]); 
title('Projection vector, p, of w on v')
text(w(1),w(2),'w = (6,2)') 
text(v(1),v(2),'v = (6,6)') 
text(p(1),p(2),'p = (4,4)')