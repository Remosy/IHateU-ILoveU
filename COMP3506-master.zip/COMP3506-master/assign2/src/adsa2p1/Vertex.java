package adsa2p1;

import java.util.ArrayList;

public class Vertex {
	ArrayList<String> AdjacentList = new ArrayList<String>(); 
	
	public ArrayList<String> GetVertex(){
		return AdjacentList;
		}
	
}
