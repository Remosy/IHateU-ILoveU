//
//  main.cpp
//  Assignment1
//
//  Created by RemosyXu on 17/3/17.
//  Copyright © 2017 RemosyXu. All rights reserved.
//
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <fstream>
#include <vector>
#include <ifaddrs.h>
#include <unistd.h>
#include <sstream>

#define DEFAULT_BUFLEN 4999
#define CRLF "\r\n"
#define iCRLF "\r\n"
#define SEND "TR>"
#define RECV "RX>"

using namespace std;

int mySocket;
int recv_n(int isocket, char*itext, int ilen);

char *c; //ip address
char** info();
char server_reply[DEFAULT_BUFLEN];

//vector<string> LOG_capsule;
string LOG_capsule;
vector<string> smtpExtension;

const char *hostname = "smtp.uq.edu.au"; //130.102.132.85
//const char *hostname = "moss.labs.eait.uq.edu.au";

struct sockaddr_in server;
struct in_addr *my_in_addr;

/**
 Replace Non-printable Char
 **/
string output(string str){
    string out;
    for(string::const_iterator it = str.begin(); it != str.end(); ++it){
        char check = *it;
        switch (check) {
            case L'\r':
                out.append("\\r");
                break;
            case L'\n':
                out.append("\\n");
                break;
            case L'\t':
                out.append("\\t");
                break;
                
            default:
                out.push_back(check);
        }
    }
    //cout<<out<<endl;
    return out;
}



/**
  Multiple-times RECV
 **/
ssize_t recv_n(int isocket) {
    ssize_t i;
    int count = 0;
    char buf[DEFAULT_BUFLEN];
    string received;
    string str;
    
    memset((char *)&buf, '\0', DEFAULT_BUFLEN);
    i = recv(isocket, buf, DEFAULT_BUFLEN-1, 0);
    received.insert(received.length(), (char *)&buf[0]);

    istringstream flag(received);
    while(getline(flag, str)) {
        str.append("\n");
        count++;
        if(count>1){
            //Add smtp extensions
            string temp = str;
            smtpExtension.push_back(temp.erase(temp.size() - 2));
        }
        str.insert (0,RECV);
        str = output(str);
        str += CRLF;
        LOG_capsule.append(str);
    }
    return i;
}

/**
 Multiple-times SEND
 **/
void send_n(int isocket, char *in) {
    string str;
    string input;
    send(isocket,in,strlen(in),0);
    str.append(SEND);
    str.append(in);
    str = output(str);
    str += CRLF;
    LOG_capsule.append(str);
}


/**
 Multiple-times Write in log
 **/
void logger(){
   // LOG_capsule.push_back();
    //char *fPath;
    //fPath = getenv ("PATH");
    //strcat(fPath, "smtplog.txt");
    string fPath = "/Users/remosy/Desktop/COMS3200"
    "/Assignment1/Assignment1/Assignment1/smtplog.txt";
    ofstream log;
    ifstream file(fPath);
    string strt;
    getline(file,strt);
    log.open(fPath,fstream::app);
    if(strt.empty()){
       log << "Name:Remosy Xu  Student Number:s4344240\n";
    }
    
    
    for (auto k = LOG_capsule.begin(); k != LOG_capsule.end(); ++k){
        log << *k;
    }

     LOG_capsule.clear();
     log.close();
    
}


/**
 Return info List:
    The fully qualified host name of server
    The IP address of server
 **/
char **getinfo(int port){
    char* ip =(char*) "";
    char **infolist = new char*;
    
    //Local
    if(port==0){
        struct hostent *hex_addr;
        char myhostname[1024];
        myhostname[1023] = gethostname(myhostname, 1023); //Local
        hex_addr = gethostbyname(myhostname);
        struct in_addr *my_in_addr = (struct in_addr*) hex_addr->h_addr_list[0];
        ip = inet_ntoa(*my_in_addr);
        infolist[0] =(char*) myhostname;
        
    }
    
    //Target
    if(port==1){
        struct hostent *hex_addr = gethostbyname(hostname);
        //cout<< "Server" <<endl;
        struct in_addr *my_in_addr = (struct in_addr*) hex_addr->h_addr_list[0];
        ip = inet_ntoa(*my_in_addr);
        infolist[0] =(char *) hostname;
    }
    
    infolist[1] = ip;
    return infolist;
}


void suc(){
    printf("Yes \n");
}

void reportError(){
    printf("No %s\n", strerror(errno));
    exit(0);
}

void connectServer(){
    mySocket = socket(AF_INET , SOCK_STREAM, 0);
    if (mySocket == -1){reportError();}else{suc();}
    char **serverInfo = getinfo(1);
    server.sin_family = AF_INET;
    server.sin_port = htons( 25 );
    server.sin_addr.s_addr = inet_addr(serverInfo[1]);
    
    if (connect(mySocket,
        (struct sockaddr *) &server,
         sizeof(server))== -1){
            reportError();
    }else{suc();}
}


int main(int argc, const char * argv[]) {
    
     char msg[255];//sent message

    //Establish connection to server
    connectServer();
    
    //Start communication
    if (recv_n(mySocket)<0){
        reportError();
    }else{suc();}

    //HELO
    sprintf(msg,"EHLO itee.uq.edu.au\r\n");
    send_n(mySocket,msg);
    recv_n(mySocket);
    
    //MAIL
    sprintf(msg,"MAIL FROM: s4344240@student.uq.edu.au\r\n");
    send_n(mySocket,msg);
    recv_n(mySocket);
    
    //RCPT
    sprintf(msg,"RCPT TO: yangyang.xu1@uq.net.au\r\n");
    send_n(mySocket,msg);
    recv_n(mySocket);
    
    //DATA
    sprintf(msg,"DATA\r\n");
    send_n(mySocket,msg);
    recv_n(mySocket);
    
    //Begin Mail
    sprintf(msg,"From: Remosy\r\n");
    send_n(mySocket,msg);
    sprintf(msg,"To: yangyang.xu1@uq.net.au\r\n");
    send_n(mySocket,msg);
    sprintf(msg,"Subject: Test Email for Assignment 1 in"
            "Computer Networks 1\r\n");
    send_n(mySocket,msg);
    sprintf(msg,"Autogenerated email message by Remosy Xu\'s test program\r\n");
    send_n(mySocket,msg);
    
    
    //Local Host
    char **localInfo = getinfo(0);
    char *lc_name =localInfo[0];
    char *lc_ip =localInfo[1];
    sprintf(msg,"FROM:\t\t %s\t [%s]\r\n", lc_name,lc_ip);
    send_n(mySocket,msg);
    
    
    //Target Host
    char **tarInfo = getinfo(1);
    char *tar_name =tarInfo[0];
    char *tar_ip =tarInfo[1];
    sprintf(msg,"TO:\t\t %s\t\t [%s]\r\n", tar_name,tar_ip);
    send_n(mySocket,msg);
    
    sprintf(msg,"This SMTP server supports the following server extensions:\r\n");
    send_n(mySocket,msg);
    
    if(!smtpExtension.empty()){
        for (auto j = smtpExtension.begin(); j != smtpExtension.end(); ++j){
            char *copy = new char[j->size()+1];
            strcpy(copy, j->c_str());
            sprintf(msg,"%s\r\n",copy);
            send_n(mySocket,msg);
        }
    }else{
        sprintf(msg,"PIPELINING\r\n");
        send_n(mySocket,msg);
        sprintf(msg,"SIZE 10000000\r\n");
        send_n(mySocket,msg);
        sprintf(msg,"DNS\r\n");
        send_n(mySocket,msg);
    }
    
    
    //End Mail
    sprintf(msg,".\r\n");
    send_n(mySocket,msg);
    recv_n(mySocket);
    
    
    //QUIT
    sprintf(msg,"QUIT\r\n");
    send_n(mySocket,msg);
    recv_n(mySocket);
    
    logger();
   
}
