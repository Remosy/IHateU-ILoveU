close all % close all figures
for k = [2.9,3.5,3.9]
%clear figure, and the vector a
clf; clear a;
%set up vector a, a_1 = 0.5
a = zeros(1,50);
a(1) = 0.5;
for n = 2:50
a(n) = k.*a(n-1).*(1-a(n-1));
end
plot(a);
title(['k=',num2str(k)]);
%pauses the loop and waits
% for any key press to continue
pause; 
end
