function f = func(x)
%Piecewise function for Module 7 Exercise 2

if x < 0
    f = x^3+x+1;

elseif x>=0 && x< pi/2
    f = cos(x)-x;

elseif pi/2 <= x
    f = cot(x)^2-x;
end