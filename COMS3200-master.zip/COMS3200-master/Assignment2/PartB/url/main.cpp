//
//  main.cpp
//  Assignment2
//
//  Created by RemosyXu on 26/4/17.
//  Copyright © 2017 RemosyXu. All rights reserved.
//
#ifdef _WIN32
#include <direct.h>
#define getcwd _getcwd
#else
#include <unistd.h>
#endif

#include <arpa/inet.h>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <future>
#include <iostream>
#include <iomanip>
#include <netdb.h>
#include <stdio.h>
#include <strings.h>
#include <sstream>
#include <stdlib.h>
#include <sys/socket.h>
#include <thread>
#include <regex>

#define PORT_HTTP 80
#define PORT_HTTPS 443
#define PORT_FTP 21
#define DEFAULT_BUFLEN 8192
#define CRLF "\r\n"

using namespace std;

void getHostPort(string);
void getPathQuery(string);
int mySocket;
int workLoad =0;
string LOG_capsule;

struct sockaddr_in server;

struct DownloadedContent{
    long length;
    string type;
}DownloadedContent;

struct URL{
    string url;
    string Scheme;
    string User;
    string Pass;
    string Host;
    int Port;
    string Path;
    string Query;
    string FileName;
    char IP[100];
}theURL;

void conn_Socket(struct URL url);

/**
 input:  raw input
 return: uri exclude scheme
**/
void getScheme(string input){
    int scm_pos = (int) input.find("://");
    string scm = input.substr(0,scm_pos);
    regex regex_scm ("(ftp|http|https)://*");
    smatch match;
    regex_search(input, match, regex_scm);
    if (regex_search(input, match, regex_scm) && (int)match.size() > 1
        && scm_pos != -1) {
        if(scm_pos>4){
            cout << "[Warn] " << "Unsupport Scheme: " << scm << endl;
            exit(0);
        }
    } else if((regex_search(input, match, regex_scm) || (int)match.size() < 1)
              && scm_pos != -1){
        cout << "[Warn] " << "Not Found Scheme: " << scm << endl;
        exit(0);
    }else if(scm_pos == -1){
        cout << "[Warn] " << "Uncompleted URI, 'http://' needed" << endl;
        exit(0);
    }
    
    theURL.Scheme = "http";
    cout << "[getSchme] " << scm_pos << "__" << theURL.Scheme << endl;
    getHostPort(input.substr(scm_pos+3));
}

/**
 input:  uri exclude scheme
 return: <Host:Port>|<User:Pass> & <Url>
**/
void getHostPort(string input){
    theURL.Port = PORT_HTTP; //Set Default Port
    cout <<"[Input] "<< input <<endl;
    int hostpost_pos = (int)input.find_first_of("/");
    string hostpost = input.substr(0,hostpost_pos);
    cout << "[HostPost] " << hostpost << endl;
    int split_index1 = (int)hostpost.find_first_of(":");
    int split_index2 = (int)hostpost.find_first_of("@");
    
    if(split_index1>-1 && split_index2>-1){
        try{
            theURL.Host = hostpost.substr(split_index2+1);
            theURL.User = hostpost.substr(0,split_index1);
            theURL.Pass = hostpost.substr(split_index1,split_index2);
        }catch (int error) {
            cout << "[Error] " << error <<endl;
            exit(0);
        }
    }else if(split_index1>0  && split_index2 < 0){
        theURL.Host = hostpost.substr(0,split_index1);
        if(hostpost.substr(split_index1+1).length()>0){
            try {
               theURL.Port = atoi(hostpost.substr(split_index1+1).c_str());
                cout << "PORT:" << theURL.Port << endl;
            } catch (int error) {
                cout << "[Error] " << error <<endl;
                exit(0);
            }
        }else{exit(0);}
    }else if(split_index1<0  && split_index2<0){
        theURL.Host = hostpost;
    }else{
        cout << "[Warn] Invalid host name" << hostpost << endl;
        exit(0);
    }
    
    theURL.url = input.substr(hostpost_pos);
    getPathQuery(theURL.url);
}

/**
 input:  url
 return: <Path?Query> & <FileName>
 **/
void getPathQuery(string input){
    int has_path = 0;
    int has_query = 0;
    cout << "[getPathQuery] "<< theURL.Host << "-->" << input << endl;
    int query_pos = (int)input.find_first_of("?");//Find all "?"
    int path_pos = (int)input.find("/");//Find all "/"
    
    if(query_pos >-1 && path_pos >-1){
        theURL.Path = input.substr(0,query_pos - 1);
        theURL.Query = input.substr(query_pos);
        has_path = 1;
        has_query = 1;
    }else if(query_pos < 0 && path_pos > -1){
        theURL.Path = input;
        theURL.Query = "";
        has_path = 1;
        has_query = 0;
    }else{
        cout << "[Warn] Please correct path" <<endl;
        exit(0);
    }
    
    int file_pos = (int)theURL.Path.find_last_of("/");
    
    if(theURL.Path.substr(file_pos+1)=="" || theURL.Path.substr(file_pos+1)=="."
       || (int)theURL.Path.substr(file_pos+1).find(".")<0){
        cout << "[Warn] Uncompleted File Name ->"
             << theURL.Path.substr(file_pos) << endl;
        exit(0);
    }
    
    
    theURL.FileName = theURL.Path.substr(file_pos);
    theURL.FileName = theURL.FileName.substr(0,(int)theURL.FileName.find("#"));
    cout << "[getFileName] " << theURL.FileName << endl;
    
   conn_Socket(theURL);
}

/**
 Establish Socket Connection
 **/
void conn_Socket(struct URL url){
    struct hostent *he;
    struct in_addr **addr_list;
    
    if ( (he = gethostbyname(url.Host.c_str()) ) == NULL){
        cout << "[Error] gethostbyname: Unknown host"<<endl;
        exit(0);
    }
    
    addr_list = (struct in_addr **) he->h_addr_list;
    
    for(int i = 0; addr_list[i] != NULL; i++){
        strcpy(theURL.IP , inet_ntoa(*addr_list[i]) );//Return first one
    }
    
    mySocket = socket(AF_INET , SOCK_STREAM, 0);
    
    if (mySocket == -1){cout << "Not Connected Socket" <<endl;}else{
        cout<< "Yes! Connected Socket!" <<endl;
    }
    
    server.sin_family = AF_INET;
    server.sin_port = htons( url.Port );
    server.sin_addr.s_addr = inet_addr(theURL.IP);
    cout << url.Port <<endl;
    
    if (connect(mySocket,
                (struct sockaddr *) &server,
                sizeof(server))== -1){
    cout << "Not Connected server" <<endl;
    }else{cout << "Yes! Connected Server!" <<endl;}
}

/**
 Multiple-times Write in log
 **/
void logger(){
    string path(getcwd(NULL,0));
    path.append(theURL.FileName);
    ofstream log;
    ifstream file(path);
    cout << "[Saved at] " << path << endl;
    string strt;
    getline(file,strt);
    log.open(path,fstream::trunc);
    
    for (auto k = LOG_capsule.begin(); k != LOG_capsule.end(); ++k)log << *k;
    
    LOG_capsule.clear();
    log.close();
}

/**
 Multiple-times RECV
 **/
void recv_n(int isocket) {
    int i = 0;
    int numChunk = 0;
    char buf[DEFAULT_BUFLEN];
    string str;
    
    do {
        memset((char *)&buf, '\0', DEFAULT_BUFLEN);
        i = (int)recv(isocket, buf, sizeof(buf)-1, 0);
        
        if(i>0){workLoad += i;}else{shutdown(isocket,SHUT_WR);break;}
        
        if(numChunk>0){LOG_capsule.append(buf);}
        
        /*First chunk needs hearder clearing*/
        if(numChunk==0){
            int isHeader = 1;
            string received;
            received.insert(0, (char *)&buf[0]);
            istringstream flag(received);
            
            while(getline(flag, str)) {
                str.append(CRLF);
                if(isHeader==0){LOG_capsule.append(str);}
                if(isHeader==1 && str.substr(0,8)=="HTTP/1.1"){
                    if((int)str.substr(9).find("200")<0){
                        cout << "[warn] " << str <<endl;
                        exit(0);
                    };
                    cout << ".............." << str <<endl;
                }
                
                if(isHeader==1 && str.substr(0,14)=="Content-Length"){
                    DownloadedContent.length = stoi(str.substr(16));
                    cout << "[GetContentLength] " <<DownloadedContent.length
                         << "Bytes" <<endl;
                }
                
                if(isHeader==1 && str.substr(0,12)=="Content-Type"){
                    DownloadedContent.type = str.substr(14);
                    cout << "[GetContentType] " << DownloadedContent.type
                         <<endl;
                }
                
                //Detect Response Header
                if(isHeader == 1 && str.find("r\r\n")>0 && str.length()==3){
                    isHeader=0;
                }
            }
        }
        numChunk++;
    } while (i > 0);
}

/**
 Multiple-times SEND
 **/
void send_n(int isocket, char *in) {
    string str;
    string input;
    send(isocket,in,strlen(in),0);
    str.append(in);
    cout << "[REQUEST SENT] " << str <<endl;
}

/**
 The command line usage for assignment
 **/
void showUsage(const char * argv, string comment){
    cerr << comment << endl << "Usage: " << argv << " http://"
    << "HOST/FILENAME"
    << endl;
    exit(0);
}

int main(int argc, const char * argv[]) {
    /**** START ****/
    if(argc>2){showUsage(argv[0],"Too many auguments");}
    if(argc<2){showUsage(argv[0],"Missing auguments");}
    
    /**** PreProcess ****/
    string input;
    input = argv[1];
    time_t rtime;
    struct tm * timeinfo;
    char timeStamp [25];
    time (&rtime);
    timeinfo = localtime (&rtime);
    strftime (timeStamp,25,"--%F %T--\t",timeinfo);
    cout << timeStamp << endl;
    
    /**** Process 1 --> SEND REQUEST****/
    getScheme(input);//-> getHostPort() -> getPathQuery() -> conn_Socket()
    char msg[255];
    sprintf(msg,"GET %s%s HTTP/1.1%sHost:%s%s%s",theURL.Path.c_str(),
            theURL.Query.c_str(),CRLF,
            theURL.Host.c_str(),CRLF,
            "Connection: close\r\n\r\n");
    send_n(mySocket, msg);
    
    /**** Process 2 --> GET RESPONSE****/
    clock_t begin = clock();
    recv_n(mySocket);
    clock_t end = clock();
    double time_interval = double(end - begin);
    cout << "[Response Speed] " << DownloadedContent.length/time_interval
         << " Bytes per Second"<<endl;
    
    /**** Process 3 --> REMAKE FILE****/
    logger();
    
    /**** END ****/
    cout << timeStamp << endl;
    
    return 0;
}
