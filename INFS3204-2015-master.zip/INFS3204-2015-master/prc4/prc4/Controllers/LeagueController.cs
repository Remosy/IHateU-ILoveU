﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using prc4.Models;
using System.IO;
using System.Collections;

namespace prc4.Controllers
{
    public class LeagueController : ApiController
    {
       
        public string fileName = @"\\psf\Home\Documents\Visual Studio 2013\Projects\prc4\prc4\players.txt";
        List<Player> pla = new List<Player>();
        public List<Player> returnPlayers()
        {
            try 
            { 
                 string[] read = File.ReadAllLines(fileName);
                foreach (string x in read)
                {
                    string[] list = x.Split(',');
                    pla.Add(new Player() {
                          RegistrationID = list[0],
                          Firstname = list[1],
                          Lastname = list[2],
                          Teamname = list[3],
                          Dateofbirth = Convert.ToDateTime(list[4])
                   
                    });
                    
                }
                return pla;
            }
            catch (Exception) { return null; }
 
        }

        public List<Player> SearchPlayers(string choice, string input)
        {
            
                List<Player> pla = new List<Player>();
                List<Player> list = returnPlayers();
                Player pl = new Player();
                pla.Clear();
                switch(choice)
                {
                    case "ID":
                        pla = list.FindAll(element => element.RegistrationID == input);
                        break;
                    case "FullName":
                        pla = list.FindAll(element => (string.Concat(element.Firstname, element.Lastname).ToUpper()).Contains((input).ToUpper()));
                        break;
                }
                return pla;
        }

        
        public List<Player> DeletePlayers(string choice, string input)
        {
             string m = ",";
             ArrayList PList = new ArrayList();
            List<Player> pla = new List<Player>();
            List<Player> list = returnPlayers();
            Player pl = new Player();
            pla.Clear();
            if (input != null)
            {
               
                switch (choice)
                {
                    case "ID":
                            pla = list.FindAll(element => element.RegistrationID.Equals(input));
                            foreach (Player p in pla) { list.Remove(p); }
                            break;
                        
                    case "FullName":
                        pla = list.FindAll(element => (string.Concat(element.Firstname, element.Lastname).ToUpper()).Contains((input).ToUpper()));
                        foreach (Player p in pla) { list.Remove(p); }
                        break;
                }
            }

            foreach(Player p in list)
            {
              string date = String.Format("{0:yyyy-MM-dd}", p.Dateofbirth);
              System.Diagnostics.Debug.WriteLine("********" + date);
              string st = p.RegistrationID + m + p.Firstname + m + p.Lastname + m + p.Teamname + m +date;
              PList.Add(st);
                //Re-Write File
              string[] bList2 = new string[PList.Count];
              bList2 = (String[])PList.ToArray(typeof(string));
              System.IO.File.WriteAllLines(fileName, bList2);
            }
            return list;
        }

       
        // GET: api/League
        public IHttpActionResult Get()
        {
            
            return Ok(returnPlayers());
           
        }

        //Search
        [Route("api/League/{choice}/{input}")]
        [HttpGet]
        public IHttpActionResult FindPlayer(string choice, string input)
        {
            System.Diagnostics.Debug.WriteLine("*Yeees");
            System.Diagnostics.Debug.WriteLine("*---"+choice);
           
            return Ok(SearchPlayers(choice, input));
          
           
        }
      
       
        // DELETE
        [Route("api/League/{choice1}/{input1}")]
        [HttpDelete]
        public IHttpActionResult Delete(string choice1, string input1)
        {
            return Ok(DeletePlayers(choice1, input1));
        }

       //Update
        [Route("api/League/Update/")]
        [HttpPost]
        public IHttpActionResult Update(Player player)
        {
           
            List<Player> list = returnPlayers();
            var pl = list.FirstOrDefault((p) => p.RegistrationID == player.RegistrationID);
            //var p = list.Find(element => element.RegistrationID == player.RegistrationID);
            if (pl != null)
            {
                list.Remove(pl);
                list.Add(player);
                writeFile(list);
                System.Diagnostics.Debug.WriteLine("********" + pl.RegistrationID);
            }
            else
            {
                list.Add(player);
                writeFile(list);
                System.Diagnostics.Debug.WriteLine("!!!!!!!!!!!"+ player.RegistrationID);
            }
            return Ok(list);
            
        }

        public void writeFile(List<Player> list)
        {
            ArrayList PList = new ArrayList();
            string m = ",";
            foreach (Player p in list)
            {
                string date = String.Format("{0:yyyy-MM-dd}", p.Dateofbirth);
                string st = p.RegistrationID + m + p.Firstname + m + p.Lastname + m + p.Teamname + m + date;
                PList.Add(st);
            }
            //Re-Write File
            string[] bList2 = new string[PList.Count];
            bList2 = (String[])PList.ToArray(typeof(string));
            System.IO.File.WriteAllLines(fileName, bList2);
        }
    }
}
