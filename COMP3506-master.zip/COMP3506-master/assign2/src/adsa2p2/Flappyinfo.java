package adsa2p2;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class Flappyinfo {
        int n = 0;
        int m = 0;
        int k = 0;
        int initialAlt = 0;
        ArrayList<Integer> X_action = new ArrayList<Integer>();
		ArrayList<Integer> Y_action = new ArrayList<Integer>();
		LinkedHashMap<Time,Gap> Pipe = new LinkedHashMap<Time,Gap>();
        		
}
