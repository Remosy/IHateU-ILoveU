x = linspace(-4, 2, 100);
f = x.^3+3.*x.^2-2.*x-4;
plot(x,f)
grid on
print('graph.png','-dpng')