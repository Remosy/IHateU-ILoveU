function fib(n)
% Set the Fibonacci number to calculate.
%n = 10;
% Create a row vector called containing n ones. 
Y = ones(1,n);
% This vector is used to store the Fibonacci
% numbers; its first element is currently F_1
% and its second element is F_2 (if n>1).
% If n>2, then use the recursive formula
% to calculate F_3, F_4, ... , F_n.
for i1 = 3:n
Y(i1) = Y(i1-1) + Y(i1-2);
%fprintf('Fibonacci no. %s = %s\n',num2str(i1),num2str(Y(i1)))
x=['Fibonacci no. ',num2str(i1),' = ',num2str(Y(i1))];
disp(x)
end
% Display last value in F.
Y(end);