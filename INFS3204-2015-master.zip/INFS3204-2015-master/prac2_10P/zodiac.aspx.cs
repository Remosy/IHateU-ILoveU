﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prac2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.ZodiacByDateSoapClient zd = new ServiceReference1.ZodiacByDateSoapClient();
            string format = (TextBox1.Text).ToString();//
            char s;
            string rest = "";
            for(int ct = 0; ct < format.Length; ct++){

                //Format the 1st char --> Uppercase
                if(ct == 0){
                   s = char.ToUpper(format[0]);
                   rest += s; 
                }
                else
                {//Format the remaindering chars --> Lowercase
                        rest += char.ToLower(format[ct]);
                }
            }

            format = rest;
            TextBox2.Text = zd.FindDate(format);
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int month = 0;
            int date = 0;

            //Validation:
            try {
                //Check input can be converted to Integer
                month = Convert.ToInt32(TextBox3.Text);
                date = Convert.ToInt32(TextBox5.Text);
            }
            catch (FormatException)
            {
                //Notification
                TextBox4.Text = "Not Found";
               
            }
           
            
            ServiceReference2.ZodiacByNameSoapClient zn = new ServiceReference2.ZodiacByNameSoapClient();
            TextBox4.Text = zn.FindName(month,date);
          
        }

       
    }
}